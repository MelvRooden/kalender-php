<?php

require_once('model.php');

createPerson($_POST);

echo "<a href=\"index.php\">Terug</a>";
