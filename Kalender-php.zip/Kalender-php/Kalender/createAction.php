<?php

require_once('connect.php');

createPerson($_POST);