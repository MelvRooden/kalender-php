<?php

require_once('connect.php');

removePerson($_POST);