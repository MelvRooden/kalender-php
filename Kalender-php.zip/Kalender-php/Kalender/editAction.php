<?php

require_once('model.php');

editPerson($_POST);

var_dump($data);

echo "<a href=\"index.php\">Terug</a>";
