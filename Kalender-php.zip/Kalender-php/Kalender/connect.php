<?php

function createDBconnection() {
    $conn = mysqli_connect(localhost, calendar_user, koekje, calendar);

    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    return $conn;
}

function getAllBirthdays() {
    $connection = createDBconnection();
    $sql = "SELECT * FROM birthdays ORDER BY month ASC, day ASC";
    $result = $connection->query($sql);
    $connection->close();
    return $result;
}

function createPerson($data) {
    $person = $data['person'];
    $day = $data['day'];
    $month = $data['month'];
    $year = $data['year'];

    $connection = createDBconnection();

    $sql = "INSERT INTO birthdays (person, day, month, year) VALUES (?, ?, ?, ?)";
    $stmt = $connection->prepare($sql);
    $stmt->bind_param("siii", $person, $day, $month, $year);

    $stmt->execute();
    $stmt->close();
    $connection->close();
}

function removePerson($id) {
    $connection = createDBconnection();
    $sql = "DELETE FROM birthdays WHERE id=$id";
    echo $sql;
    $connection->query($sql);
    $connection->close();
}