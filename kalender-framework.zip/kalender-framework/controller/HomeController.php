<?php

function index()
{
	render("home/index");	
}