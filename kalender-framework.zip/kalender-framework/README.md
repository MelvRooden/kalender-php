Vergeet niet de config.php voor gebruik aan te passen aan jou wamp omgeving.
